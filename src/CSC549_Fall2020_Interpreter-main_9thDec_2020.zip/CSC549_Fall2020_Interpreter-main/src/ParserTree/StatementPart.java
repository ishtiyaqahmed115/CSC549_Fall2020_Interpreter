package ParserTree;

public abstract class StatementPart extends PartTree
{
	public StatementPart()
	{
		super("StatementPart");
	}
}
