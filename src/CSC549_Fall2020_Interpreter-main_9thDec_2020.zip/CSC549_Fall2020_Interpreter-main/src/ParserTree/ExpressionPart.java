package ParserTree;

public abstract class ExpressionPart extends PartTree 
{
	public ExpressionPart()
	{
		super("ExpressionPart");
	}
}
